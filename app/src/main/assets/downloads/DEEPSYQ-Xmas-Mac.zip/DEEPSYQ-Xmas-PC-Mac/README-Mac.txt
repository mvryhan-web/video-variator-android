DEEPSYQ Xmas PC for macOS
Double-click Start-Xmas-PC.command to launch the interactive winter desktop.