#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
open -a Safari "$DIR/DEEPSYQ-Xmas-Desktop.html" || open "$DIR/DEEPSYQ-Xmas-Desktop.html"
